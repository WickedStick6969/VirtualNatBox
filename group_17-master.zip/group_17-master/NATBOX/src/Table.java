public class Table extends Thread {

    private final int timer;
    private final int time_alive;
    boolean running;

    public Table(int timer, int time_alive) {
        this.timer = timer;
        this.time_alive = time_alive;
    }

    public void run() {
        running = true;
        while (running) {
            // System.out.println("Hello from table");
            try {
                for (int i = 0; i < NATBox.natTable.size(); i++) {
                    boolean remove = true;
                    for (int j = 0; j < NATBox.clientList.size(); j++) {
                        //this checks if the clients ip address is equal to the tables ip for that entry
                        if (NATBox.clientList.get(j).getIp_address().equalsIgnoreCase(NATBox.natTable.get(i).getInternal_IP())) {
                            remove = false;
                            break;
                        }
                    }

                    if ((System.nanoTime() - NATBox.natTable.get(i).getTimestamp()) / 1000000 > time_alive) {
                        remove = true;
                    }

                    if (remove) {
                        NATBox.natTable.remove(i);
                    }
                }
                Thread.sleep(timer);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        closeThread();
    }

    private void closeThread() {
        running = false;
    }

}
