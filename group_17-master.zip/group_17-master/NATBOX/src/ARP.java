import java.io.Serializable;

public class ARP implements Serializable, Message {
    public static final int REQUEST = 1;
    public static final int RESPONSE = 2;
    private String ip;
    private String mac;
    private int type;

    public ARP(int type) {
        this.type = type;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public int getTypeOfMessage() {
        return 3;
    }
}
