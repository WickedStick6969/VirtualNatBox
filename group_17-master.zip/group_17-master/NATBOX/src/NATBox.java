import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class NATBox {
    private static int startIP1;
    private static int startIP2;

    public static final String Mac_Address = "78:ca:39:bb:5d:11";
    public static String natIP; // IP address
    private String startIpInt = "10.10.";
    private String startIpExt = "146.232.";
    private ServerSocket serverSocket;
    private static ThreadedNAT threadedNAT;


    private int port;
    private int poolSize;
    private int tableRefreshRate;
    private int tableRefreshInterval;
    int unique_ID = 0;
    private boolean running = true;
    String ip_address;

    ObjectInputStream inputStream;
    ObjectOutputStream outputStream;

    public static ArrayList<NAT> natTable;
    public static ArrayList<String> availableIPint;
    public static ArrayList<String> availableIPext;
    public static ArrayList<ThreadedClient> clientList;


    public NATBox(int port, int poolSize, int tableRefreshRate, int tableRefreshInterval) {
        natTable = new ArrayList<>();
        clientList = new ArrayList<>();
        Table table = new Table(tableRefreshRate, tableRefreshInterval);
        table.start();
        this.port = port;
        this.poolSize = poolSize;
        this.tableRefreshRate = tableRefreshRate;
        this.tableRefreshInterval = tableRefreshInterval;
        initializeIP();
        natIP = getNewIP(Client.EXTERNAL);

    }

    /**
     * The method returns the next available IP depending on the client type and removes that
     * IP from the IP pool.
     *
     * @param type
     * @return
     */
    public static String getNewIP(int type) {
        if (type == Client.INTERNAL) {
            return availableIPint.remove(0);
        } else {
            return availableIPext.remove(0);
        }
    }

    /**
     * Method used to add an entry to the nat table
     *
     * @param nat
     */
    public static void addNAT(NAT nat) {
        natTable.add(nat);
        printTable();
    }

    /**
     * Used for debugging
     */
    public static void printTable() {
        System.out.println("\nNAT table\n-------------------------------------------");
        for (ThreadedClient client : clientList) {
            System.out.println(client.ip_address);

        }
        System.out.println("-------------------------------------------");
    }

    public static void setThreadedNAT(ThreadedNAT threadedNAT) {
        NATBox.threadedNAT = threadedNAT;
    }

    private void initializeIP() {
        availableIPint = new ArrayList<>();
        availableIPext = new ArrayList<>();

        startIP1 = 0;
        startIP2 = 0;

        for (int i = 0; i < poolSize; i++) {
            String ip = genNewIP(Client.INTERNAL);
            availableIPint.add(ip);
        }

        startIP1 = 0;
        startIP2 = 0;

        for (int i = 0; i < poolSize; i++) {
            String ip = genNewIP(Client.EXTERNAL);
            availableIPext.add(ip);
        }
    }

    /**
     * Generates a new IP for a client depending on whether the client type is internal or external.
     *
     * @param type - client type
     * @return IP for client
     */
    public String genNewIP(int type) {
        String ip;
        if (type == Client.INTERNAL) {
            ip = startIpInt;
        } else {
            ip = startIpExt;
        }
        ip += startIP1 + "." + startIP2;
        if (startIP2 == 999) {
            startIP2 = 0;
            startIP1++;
        } else {
            startIP2++;
        }
        return ip;


    }

    public void start() {
        try {
            serverSocket = new ServerSocket(port);

            while (running) {
                System.out.println("Waiting for client connections");
                Socket socket = serverSocket.accept();
                ThreadedClient client = new ThreadedClient(socket, unique_ID++);
                client.start();
                clientList.add(client);
                System.out.println("Client connected");
                printTable();
            }
            try {
                serverSocket.close();
                for (ThreadedClient current_client : clientList) {
                    current_client.close();

                }
            } catch (IOException e) {
                System.err.println("Error closing the server and clients");
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }


    public static void sendPacket(Packet packet) {
        if (packet.getDestinationAddress().equals(natIP)) {
            threadedNAT.writePacket(packet);
        } else {
            for (ThreadedClient current_client : clientList) {
                if (current_client.getIp_address().equals(packet.getDestinationAddress())) {
                    current_client.writePacket(packet);
                    break;
                }
            }
        }
    }


    public static void main(String[] args) {

        try {
            int port = Integer.parseInt(args[0]);
            int poolSize = Integer.parseInt(args[1]);
            int tableRefreshRate = Integer.parseInt(args[2]);
            int time_to_live = Integer.parseInt(args[3]);

            NATBox router = new NATBox(port, poolSize, tableRefreshRate, time_to_live);
            router.start();

        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("Arguments Required: <port> <poolSize> <tableRefreshRate> <time_to_live>");
        } catch (IndexOutOfBoundsException e) {
            System.err.println("There are not enough available IP addresses");

        }


    }
}
