import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ThreadedNAT extends Thread {
    Socket socket;
    ObjectOutputStream outputStream;
    ObjectInputStream inputStream;
    String ip_address;

    boolean running = true;

    public ThreadedNAT(Socket socket, String ip_address) {
        try {
            this.socket = socket;
            outputStream = new ObjectOutputStream(socket.getOutputStream());

            this.ip_address = ip_address;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    boolean isInternal(String ip_address) {
        ip_address = ip_address.substring(0, 6);
        return ip_address.equalsIgnoreCase("10.10.");
    }

    @Override
    public void run() {
        System.out.println("NAT IP: " + ip_address);
        while (running) {
            try {
                if (!socket.isConnected()) {
                    System.out.println("No socket connected for threaded nat");
                    break;
                }
                inputStream = new ObjectInputStream(socket.getInputStream());
                Message message = (Message) inputStream.readObject();
                switch (message.getTypeOfMessage()) {
                    case 0:
                        DHCPMessage dhcpMessage = (DHCPMessage) message;
                        System.out.println("DHCP Received: " + dhcpMessage);
                        break;
                    case 1:
                        ICMPMessage icmpMessage = (ICMPMessage) message;
                        System.out.println("ICMP Message: " + icmpMessage.getMessage());
                    case 2:
                        Packet packet = (Packet) message;
                        System.out.println("Beginning Packet Evaluation");
                        if (!isInternal(packet.getSourceAddress()) && isInternal(packet.getDestinationAddress())) {
                            boolean sent = false;
                            for (int i = 0; i < NATBox.natTable.size(); i++) {
                                if (ip_address.equalsIgnoreCase(NATBox.natTable.get(i).getInternal_IP())) {
                                    packet.setDestinationAddress(NATBox.natTable.get(i).getInternal_IP());
                                    sent = true;
                                    NATBox.sendPacket(packet);
                                    break;
                                }
                            }
                        }
                        break;
                }
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public void writePacket(Packet packet) {
        try {
            outputStream.writeObject(packet);
        } catch (IOException e) {
            System.out.println("Exception writing");
        }
    }

}
