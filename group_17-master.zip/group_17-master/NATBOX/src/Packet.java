import java.io.Serializable;

public class Packet implements Serializable, Message {

    public static final int TCP = 0;
    public static final int UDP = 1;
    public static final int ICMP = 2;
    public static final int ACK = 3;

    private String sourceAddress;
    private String destinationAddress;
    private int type;
    private int protocol;
    private int code;
    private int checksum;
    private byte[] packet_data;

    /**
     * This constructor is used when a packet object is created without a type
     *
     * @param data
     */
    public Packet(byte[] data) {
        packet_data = data;
    }

    /**
     * This constructor is used when a packet object is created with a type
     *
     * @param data
     * @param type
     */
    public Packet(byte[] data, int type) {
        packet_data = data;
        this.type = type;
    }

    public String getSourceAddress() {
        return sourceAddress;
    }

    public void setSourceAddress(String sourceAddress) {
        this.sourceAddress = sourceAddress;
    }

    public String getDestinationAddress() {
        return destinationAddress;
    }

    public void setDestinationAddress(String destinationAddress) {
        this.destinationAddress = destinationAddress;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getProtocol() {
        return protocol;
    }

    public void setProtocol(int protocol) {
        this.protocol = protocol;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public int getChecksum() {
        return checksum;
    }

    public void setChecksum(int checksum) {
        this.checksum = checksum;
    }

    public byte[] getPacket_data() {
        return packet_data;
    }

    public void setPacket_data(byte[] packet_data) {
        this.packet_data = packet_data;
    }

    @Override
    public int getTypeOfMessage() {
        return 2;
    }
}
