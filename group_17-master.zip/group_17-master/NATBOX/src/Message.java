public interface Message {
    //0 - dhcp :Dynamic Host Configuration Protocol (DHCP)
    //          is a client/server protocol that automatically provides an Internet Protocol (IP) host with its IP address
    //          and other related configuration information such as the subnet mask and default gateway.
    //1 - ICMP  :The Internet Control Message Protocol (ICMP) is a protocol that devices within a network used to communicate problems with data transmission.
    //           one of the primary ways in which ICMP is used is to determine if data is getting to its destination and at the right time.
    //2 - Packet : A stimulated packet
    //3 - ARP: a communication protocol used for discovering the link layer address,
    //         such as a MAC address, associated with a given internet layer address, typically an IPv4 address.


    int getTypeOfMessage();
}
