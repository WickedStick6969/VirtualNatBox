import java.io.Serializable;

public class DHCPMessage implements Serializable, Message {

    public static final int DHCP_REQUEST = 1;
    public static final int DHCP_REPLY = 2;
    private String ip;
    private int type;
    private int ipType;

    public DHCPMessage(int type, int ipType) {
        this.type = type;
        this.ipType = ipType;
    }

    public DHCPMessage(int type) {
        this.type = type;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getIpType() {
        return ipType;
    }

    public void setIpType(int ipType) {
        this.ipType = ipType;
    }

    @Override
    public int getTypeOfMessage() {
        return 0;
    }
}
