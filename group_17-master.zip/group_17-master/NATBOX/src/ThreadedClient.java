import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ThreadedClient extends Thread {
    Socket socket;
    ObjectInputStream inputStream;
    ObjectOutputStream outputStream;


    String ip_address;
    String mac_address;
    int id;
    boolean running = true;

    public ThreadedClient(Socket socket, int id) {
        this.socket = socket;
        this.id = id;

        try {
            outputStream = new ObjectOutputStream(socket.getOutputStream());
            inputStream = new ObjectInputStream(socket.getInputStream());

            DHCPMessage dhcpMessage = (DHCPMessage) inputStream.readObject();

            if (dhcpMessage.getType() == DHCPMessage.DHCP_REQUEST) {
                if (dhcpMessage.getIpType() == Client.INTERNAL) {
                    ip_address = NATBox.getNewIP(Client.INTERNAL);
                } else {
                    ip_address = NATBox.getNewIP(Client.EXTERNAL);
                }
                DHCPMessage dhcpMessageReturn = new DHCPMessage(DHCPMessage.DHCP_REPLY);
                dhcpMessageReturn.setIp(ip_address);
                outputStream.writeObject(dhcpMessageReturn);
            }
            ARP arp = (ARP) inputStream.readObject();
            if (arp.getType() == ARP.REQUEST) {
                ARP response = new ARP(ARP.RESPONSE);
                response.setIp(NATBox.natIP);
                response.setMac(NATBox.Mac_Address);
                outputStream.writeObject(response);

            }
            arp = (ARP) inputStream.readObject();
            if (arp.getType() == ARP.RESPONSE) {
                mac_address = arp.getMac();

            }
            System.out.println("Mac address received: " + mac_address);


        } catch (IOException e) {
            System.err.println("Error creating new Input/output:" + e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public String getIp_address() {
        return ip_address;
    }

    @Override
    public void run() {

        while (running) {
            try {
                if (!socket.isConnected()) {
                    break;
                }

                Packet packet_received = (Packet) inputStream.readObject();
                System.out.println("Packet received, beginning evaluation");

                boolean destination_exists = false;
                if (packet_received.getDestinationAddress().equals(NATBox.natIP)) {
                    destination_exists = true;
                } else {
                    for (ThreadedClient current_client : NATBox.clientList) {
                        if (current_client.getIp_address().equals(packet_received.getDestinationAddress())) {
                            destination_exists = true;
                            System.out.println("Sent to client: " + packet_received.getDestinationAddress());
                            break;
                        }
                    }
                }
                if (destination_exists) {
                    //If the destination exists then get the source address and the destination and send it.
                    //This is for internal -> internal

                    if (isInternal(packet_received.getSourceAddress()) && isInternal(packet_received.getDestinationAddress())) {
                        NATBox.sendPacket(packet_received);
                        // internal -> external
                    } else if (isInternal(packet_received.getSourceAddress()) && !isInternal(packet_received.getDestinationAddress())) {
                        System.out.println("IP Header modified: Source Address:" + packet_received.getSourceAddress() + "->" + NATBox.natIP);
                        packet_received.setSourceAddress(NATBox.natIP);
                        //Add or edit the natTable entry
                        for (int i = 0; i < NATBox.natTable.size(); i++) {
                            if (ip_address.equalsIgnoreCase(NATBox.natTable.get(i).getInternal_IP())) {
                                NATBox.natTable.remove(i);
                            } else if (packet_received.getDestinationAddress().equalsIgnoreCase(NATBox.natTable.get(i).getExternal_IP())) {
                                NATBox.natTable.remove(i);
                            }
                        }
                        NAT nat = new NAT(ip_address, packet_received.getDestinationAddress());
                        NATBox.addNAT(nat);
                        NATBox.sendPacket(packet_received);

                        //External -> internal
                    } else if (!isInternal(packet_received.getSourceAddress()) && packet_received.getDestinationAddress().equals(NATBox.natIP)) {
                        boolean sent = false;
                        for (int i = 0; i < NATBox.natTable.size(); i++) {
                            if (ip_address.equalsIgnoreCase(NATBox.natTable.get(i).getExternal_IP())) {
                                //Now send the packet according to the table
                                System.out.println("IP Header modified: DestinationAddress: " + packet_received.getDestinationAddress() + "->" + NATBox.natTable.get(i).getInternal_IP());
                                packet_received.setDestinationAddress(NATBox.natTable.get(i).getInternal_IP());
                                sent = true;
                                NATBox.sendPacket(packet_received);
                                break;
                            }
                        }
                        if (!sent) {
                            //Drop the packet
                            createICMP(new ICMPMessage(ICMPMessage.ERROR, " The packet is dropped, reroute via external networks!"));

                        }
                        //External -> external
                    } else {
                        createICMP(new ICMPMessage(ICMPMessage.ERROR, " The packet could not be delivered"));
                    }

                } else {
                    createICMP(new ICMPMessage(ICMPMessage.ERROR, "The destination address does not exist"));
                }

            } catch (EOFException ex) {
                System.out.println("Client Disconnected");

                break;
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        //Adds the ip address to the pool
        if (isInternal(ip_address)) {
            NATBox.availableIPint.add(ip_address);
        } else {
            NATBox.availableIPext.add(ip_address);
        }
        close();
        System.out.println("IP " + ip_address + " added back to pool of available addresses");
        NATBox.printTable();

    }

    public void createICMP(ICMPMessage icmpMessage) {
        try {
            outputStream.writeObject(icmpMessage);
        } catch (IOException e) {
            System.out.println("Exception writing the ICMP message");
        }
    }

    public void writePacket(Packet packet) {
        try {
            outputStream.writeObject(packet);
        } catch (IOException e) {
            System.out.println("Exception writing the packet");
        }
    }

    /**
     * The close method is used for thread safety and closes all the streams so that the thread can be
     * closed properly>
     */
    public void close() {
        try {
            if (outputStream != null) {
                outputStream.close();
            }
        } catch (IOException e) {
            System.err.println(e);
        }
        try {
            if (inputStream != null) {
                inputStream.close();
            }
        } catch (IOException e) {
            System.err.println(e);
        }
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            System.err.println(e);
        }
        NATBox.clientList.remove(this);
    }

    boolean isInternal(String ip_address) {

        ip_address = ip_address.substring(0, 6);
        return ip_address.equalsIgnoreCase("10.10.");
    }
}
