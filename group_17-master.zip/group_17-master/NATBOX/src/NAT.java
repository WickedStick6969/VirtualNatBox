public class NAT {
    private String internal_IP;
    private String external_IP;
    private long timestamp;

    /**
     * Constructor for a NAT object
     *
     * @param internal_IP - Internal IP address for this NAT table entry
     * @param external_IP - External IP address for this NAT table entry
     */
    public NAT(String internal_IP, String external_IP) {
        this.internal_IP = internal_IP;
        this.external_IP = external_IP;
    }

    public String getInternal_IP() {
        return internal_IP;
    }

    public void setInternal_IP(String internal_IP) {
        this.internal_IP = internal_IP;
    }

    public String getExternal_IP() {
        return external_IP;
    }

    public void setExternal_IP(String external_IP) {
        this.external_IP = external_IP;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * Resets the NAT table entries time to live.
     */
    public void resetTimestamp() {
        timestamp = System.nanoTime();
    }

    /**
     * Just returns the NAT table entries object in a string representation
     *
     * @return
     */
    public String toString() {
        return internal_IP + "<->" + external_IP;
    }
}
