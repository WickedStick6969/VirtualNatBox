import java.io.Serializable;

public class ICMPMessage implements Serializable, Message {

    public static final int ERROR = 0;
    public static final int PING = 1;

    private int type;
    private String message;

    /**
     * Constructor for the ICMPMessage object
     *
     * @param type    - the type of ICMPMessage
     * @param message - the message to be sent with this ICMPMessage
     */
    public ICMPMessage(int type, String message) {
        this.type = type;
        this.message = message;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Returns the type of the message.
     */
    @Override
    public int getTypeOfMessage() {
        return 1; // The value one comes from the Message interface
    }
}
