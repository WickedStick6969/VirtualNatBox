/*The clients that must be implemented must have the following properties:
        1. Each client must either be designated as an internal or external client, as discussed above.
        2. The clients’ IP addresses should reflect their status as either internal or external clients.
        3. Internal clients should use a minimal DHCP implementation to request an IP address.
        4. Every client must have a unique (simulated) MAC address
        5. No GUI is required for the client, however it should have the ability to send a simple paquet to a
        targeted client.
        6. The client must provide a reply for every paquet received (This is not the case with ICMP error
        paquets). This may take the form of an ACK or a similar type of packet.
        Your simulator must minimally support the following protocols and paquets:
        1. ICMP paquet forwarding (error and echo/response paquets)
        2. TU (TCP / UDP) paquet forwarding
        3. A minimal DHCP implementation*/

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.util.Random;
import java.util.Scanner;

public class Client {
    //1. Each client must either be designated as an internal or external client
    public static final int INTERNAL = 0;
    public static final int EXTERNAL = 1;

    private int type;
    private int port;
    private String ip_address;
    private String mac_address;
    private String server;

    private Socket socket;
    private ObjectOutputStream client_output;
    private ObjectInputStream client_input;

    private static String NAT_MacAddress;
    private static String NAT_IpAddress;

    /**
     * Constructor for client object.
     *
     * @param server      - the server IP address
     * @param port        - the port of the server
     * @param type        - the type of client (INTERNAL/EXTERNAL)
     * @param mac_address - the mac_address assigned to this specific client object
     */
    public Client(String server, int port, int type, String mac_address) {
        this.server = server;
        this.port = port;
        this.type = type;
        this.mac_address = mac_address;
    }


    public void sendPacket(int protocolType, String destinationAddress) {
        try {
            byte[] bytes = new byte[576];
            Packet packet = new Packet(bytes, protocolType);
            packet.setDestinationAddress(destinationAddress);
            packet.setSourceAddress(ip_address);
            client_output.writeObject(packet);
        } catch (IOException e) {
            System.out.println("NAT BOX Disconnected, Please reconnect to NAT BOX");
            System.err.println("TERMINATED");
            System.exit(2);

        }
    }

    public boolean start() {
        try {
            socket = new Socket(server, port);
        } catch (IOException e) {
            return false;
        }
        try {
            client_input = new ObjectInputStream(socket.getInputStream());
            client_output = new ObjectOutputStream(socket.getOutputStream());
        } catch (IOException e) {
            System.out.println("Problem connecting to the server");
            return false;
        }
        try {
            DHCPMessage message;
//2. The clients’ IP addresses should reflect their status as either internal or external clients.
            if (type == INTERNAL) {
                //3. Internal clients should use a minimal DHCP implementation to request an IP address.
                message = new DHCPMessage(DHCPMessage.DHCP_REQUEST, INTERNAL);
//2. The clients’ IP addresses should reflect their status as either internal or external clients.
            } else {
                message = new DHCPMessage(DHCPMessage.DHCP_REQUEST, EXTERNAL);
            }

            client_output.writeObject(message);
            DHCPMessage messageReturned = (DHCPMessage) client_input.readObject();
            if (messageReturned.getType() == DHCPMessage.DHCP_REPLY) {
                ip_address = messageReturned.getIp();
            }

            ARP arp = new ARP(ARP.REQUEST);
            client_output.writeObject(arp);
            ARP arpReturned = (ARP) client_input.readObject();
            if (arpReturned.getType() == ARP.RESPONSE) {
                NAT_MacAddress = arpReturned.getMac();
                NAT_IpAddress = arpReturned.getIp();

            }
            arp = new ARP(ARP.RESPONSE);
            arp.setMac(mac_address);
            client_output.writeObject(arp);

        } catch (IOException e) {
            System.out.println("Error when sharing IP");
            disconnect();
            return false;
        } catch (ClassNotFoundException ex) {
            System.out.println("Class not found properly");
        }
        new Server().start();
        return true;
    }

    class Server extends Thread {
        public void run() {

            while (true) {
                try {
                    Message msg = (Message) client_input.readObject();
                    switch (msg.getTypeOfMessage()) {
                        case 0 -> {
                            DHCPMessage dhcpMessage = (DHCPMessage) msg;
                            System.out.println("DHCPMessage received");
                        }
                        case 1 -> {
                            ICMPMessage icmpMessage = (ICMPMessage) msg;
                            System.out.println("ICMPMessage received" + icmpMessage.getMessage());
                        }
                        case 2 -> {
                            Packet packet = (Packet) msg;
                            if (packet.getType() == Packet.ACK) {
                                System.out.println("ACK received");
                                System.out.println("Sent packet to " + packet.getSourceAddress());
                            } else {
                                System.out.println("Packet received");
                                sendPacket(Packet.ACK, packet.getSourceAddress());

                            }
                        }
                    }
                } catch (SocketException exception) {
                    break;
                } catch (IOException e) {
                    System.out.println("Nat Box disconnected");
                    System.exit(2);
                    break;
                } catch (ClassNotFoundException ex) {
                    System.out.println("Problem with the class");
                    System.err.println();
                    break;
                }
            }
        }

    }


    /**
     * This method is used for stability purposes. It disconnects the client from the server by first
     * Closing the socket and then streams.
     */
    private void disconnect() {
        System.out.println("System Disconnected");
        try {
            if (client_input != null) {
                client_input.close();
            }

        } catch (IOException e) {
            System.out.println("Error closing client input");
        }
        try {
            if (client_output != null) {
                client_output.close();
            }
        } catch (IOException e) {
            System.out.println("Error closing client output");
        }
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            System.out.println("Error closing socket");
        }
    }

    /**
     * 4. Every client must have a unique (simulated) MAC address
     *
     * @return
     */
    private static String randomMACAddress() {
        Random random = new Random();
        byte[] randMacAddress = new byte[6];
        random.nextBytes(randMacAddress);
        //Zeroed the last 2 bytes to make it unicast and locally administrative
        randMacAddress[0] = (byte) (randMacAddress[0] & (byte) 254);

        StringBuilder stringBuilder = new StringBuilder(18);
        for (byte bytes : randMacAddress) {
            if (stringBuilder.length() > 0) {
                stringBuilder.append(":");
            }
            stringBuilder.append(String.format("%02x", bytes));
        }
        return stringBuilder.toString();
    }

    public static void main(String[] args) {
        try {
            String server = args[0];
            int port = Integer.parseInt(args[1]);
            int type = Integer.parseInt(args[2]);
            Client client = new Client(server, port, type, randomMACAddress());

            if (!client.start()) {
                System.out.println("There is no server to connect to on:\nIP: " + server + "\nPort: " + port);
                System.exit(1);
            }
            System.out.println("Successfully connected to: " + client.ip_address);
            System.out.println("IP Address of the NAT: " + NAT_IpAddress);
            System.out.println("MAC Address of the NAT: " + NAT_MacAddress);
            String inputStream;
            System.out.println("To simulate sending a packet, please enter an IP address to send a packet to.");
            System.out.println("To PING a client, 'ping <ip>'\n");
            System.out.println("To exit enter '/e'.");

            while (true) {
                Scanner scanner = new Scanner(System.in);
                inputStream = scanner.nextLine();
                if (inputStream.equals("/e")) {
                    break;
                } else if (inputStream.startsWith("ping ")) {
                    String pingIp = inputStream.split(" ")[1];
                    try {
                        InetAddress geek = InetAddress.getByName(pingIp);
                        System.out.println("Sending Ping Request to " + pingIp);
                        if (geek.isReachable(5000)) {
                            System.out.println("Ping sent to " + pingIp);
                        } else {
                            System.out.println("Sorry ! We can't reach to this host");
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                } else {
                    client.sendPacket(0, inputStream.trim());
                }
            }
            client.disconnect();

        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("Arguments Required: <Server> <Port> <Type>");
        }
    }


}
